const baseUrl = "http://49.50.69.229:5555/api/v1/web/";
// const baseUrl = "https://uatsfamt.godfreyphillips.co:3000/api/v1/web/";
// const baseUrl = "http://127.0.0.1:8000/api/v1/web/";
export const environment = {
  production: false,
  baseUrl: baseUrl,
  apiURL: `${baseUrl}`,
};