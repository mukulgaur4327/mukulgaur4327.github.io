import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { GoldReceiptRoutingModule } from './gold-receipt-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    GoldReceiptRoutingModule
  ]
})
export class GoldReceiptModule { }
