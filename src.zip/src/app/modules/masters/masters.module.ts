import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MastersRoutingModule } from './masters-routing.module';
import { MasterManagementComponent } from './master-management/master-management.component';
import { MasterSidebarComponent } from './master-sidebar/master-sidebar.component';
import { ParentModule } from '../parent/parent.module';
import { AngularMaterialModule } from 'src/app/angular-material.module';


@NgModule({
  declarations: [
    MasterManagementComponent,
    MasterSidebarComponent
  ],
  imports: [
    CommonModule,
    MastersRoutingModule,
    ParentModule,
    AngularMaterialModule
  ],
  exports: [
    MasterSidebarComponent
  ]
})
export class MastersModule { }
