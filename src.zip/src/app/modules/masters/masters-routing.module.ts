import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MasterManagementComponent } from './master-management/master-management.component';
import { MasterSidebarComponent } from './master-sidebar/master-sidebar.component';

const routes: Routes = [
  { path: "master-sidebar", component: MasterSidebarComponent },
  { path: "master-management", component: MasterManagementComponent },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MastersRoutingModule { }
