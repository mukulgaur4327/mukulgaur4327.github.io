import { Component } from '@angular/core';
import { CommonService } from '../../../common/common.service'
@Component({
  selector: 'app-master-sidebar',
  templateUrl: './master-sidebar.component.html',
  styleUrls: ['./master-sidebar.component.css']
})
export class MasterSidebarComponent {


  mastersMgmt: any;

  constructor(private service: CommonService) {
    this.mastersMgmt = this.service.mastersMgmtData();
  }

  ngOnInit() { }
}



