import { Component } from '@angular/core';
import { CommonService } from '../../../common/common.service'
@Component({
  // this is attribute selector
  selector: 'app-master-side-bar',
  templateUrl: './master-side-bar.component.html',
  styleUrls: ['./master-side-bar.component.css']
})
export class MasterSideBarComponent {
  mastersMgmt: any;

  constructor(private service: CommonService) {
    this.mastersMgmt = this.service.mastersMgmtData();
  }

  ngOnInit() { }
}
