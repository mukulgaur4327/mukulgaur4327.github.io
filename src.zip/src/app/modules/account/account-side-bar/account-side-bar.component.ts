import { Component } from '@angular/core';
import { CommonService } from '../../../common/common.service'
@Component({
  selector: 'app-account-side-bar',
  templateUrl: './account-side-bar.component.html',
  styleUrls: ['./account-side-bar.component.css']
})
export class AccountSideBarComponent {
  accMgmt: any;
  constructor(private service: CommonService) {
    this.accMgmt = this.service.accountMgmtData();
  }
  ngOnInit() { }
}
