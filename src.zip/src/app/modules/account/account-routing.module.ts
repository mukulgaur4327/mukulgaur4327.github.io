import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AccountOpeningComponent } from './account-opening/account-opening.component';
import { CollateralLinkingComponent } from './collateral-linking/collateral-linking.component';

const routes: Routes = [
  {
    path:'account', redirectTo:'account-opening', pathMatch:'full'
  },
  {
    path:'account-opening', component:AccountOpeningComponent
  },
  {
    path:'collateral-linking', component: CollateralLinkingComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AccountRoutingModule { }
