import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AccountRoutingModule } from './account-routing.module';
import { AccountOpeningComponent } from './account-opening/account-opening.component';
import { MatDividerModule } from '@angular/material/divider';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { MatTableModule } from '@angular/material/table';
import { CollateralLinkingComponent } from './collateral-linking/collateral-linking.component';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    AccountOpeningComponent,
    CollateralLinkingComponent
  ],
  imports: [
    CommonModule,
    AccountRoutingModule,
    MatDividerModule,
    MatSelectModule,
    MatButtonModule,
    MatDatepickerModule,
    BsDatepickerModule.forRoot(),
    MatTableModule,
    FormsModule
  ]
})
export class AccountModule { }
