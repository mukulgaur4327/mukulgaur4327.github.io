import { Component } from '@angular/core';
import { CommonService } from '../../../common/common.service'

@Component({
  selector: 'app-transition-side-bar',
  templateUrl: './transition-side-bar.component.html',
  styleUrls: ['./transition-side-bar.component.css']
})
export class TransitionSideBarComponent {
  transitionsMgmt: any;

  constructor(private service: CommonService) {
    this.transitionsMgmt = this.service.transitionsMgmtData();
  }
}
