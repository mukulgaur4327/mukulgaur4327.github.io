import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TransitionSideBarComponent } from './transition-side-bar.component';

describe('TransitionSideBarComponent', () => {
  let component: TransitionSideBarComponent;
  let fixture: ComponentFixture<TransitionSideBarComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TransitionSideBarComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TransitionSideBarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
