import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TransitionsRoutingModule } from './transitions-routing.module';
import { TransitionSideBarComponent } from './transition-side-bar/transition-side-bar.component';
import { ParentModule } from '../parent/parent.module';


@NgModule({
  declarations: [
    TransitionSideBarComponent
  ],
  imports: [
    CommonModule,
    TransitionsRoutingModule,
    ParentModule
  ]
})
export class TransitionsModule { }
