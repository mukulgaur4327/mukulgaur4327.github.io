import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ParentRoutingModule } from './parent-routing.module';
import { DashboardPageComponent } from './dashboard-page/dashboard-page.component';
import { MatCardModule } from '@angular/material/card';
import { LoginComponent } from './login/login.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AngularMaterialModule } from 'src/app/angular-material.module';
import { HeaderComponent } from './header/header.component';




@NgModule({

    declarations: [
        DashboardPageComponent,
        LoginComponent,
        HeaderComponent
        
    ],
    imports: [
        CommonModule,
        ParentRoutingModule,
        MatCardModule,
        ReactiveFormsModule,
        FormsModule,
        AngularMaterialModule

    ],
  


  exports: [
    HeaderComponent
  ]
})
export class ParentModule { }
