import { Component } from '@angular/core';
import { CommonService } from '../../../common/common.service'
@Component({
  selector: 'app-customer-side-bar',
  templateUrl: './customer-side-bar.component.html',
  styleUrls: ['./customer-side-bar.component.css']
})
export class CustomerSideBarComponent {
  customerMgmt: any;

  constructor(private service: CommonService) {
    this.customerMgmt = this.service.customerMgmtData();
  }
  ngOnInit() { }
}
