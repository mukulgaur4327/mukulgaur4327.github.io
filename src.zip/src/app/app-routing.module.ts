import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';


const routes: Routes = [
  {
    path: '',
    loadChildren: () => import("./modules/parent/parent.module").then(m => m.ParentModule)
  }
  ,
  {
    path: "master",
    loadChildren: () =>
      import("./modules/masters/masters.module").then(
        (m) => m.MastersModule
      ),
  },
  {
    path: "customer",
    loadChildren: () =>
      import("./modules/customer/customer.module").then(
        (m) => m.CustomerModule
      )
  },
  {
    path: "account",
    loadChildren: () =>
      import("./modules/account/account.module").then(
        (m) => m.AccountModule
      )
  },
  {
    path: "reports",
    loadChildren: () =>
      import("./modules/reports/reports.module").then(
        (m) => m.ReportsModule
      )
  },
  {
    path: "transitions",
    loadChildren: () =>
      import("./modules/transitions/transitions.module").then(
        (m) => m.TransitionsModule
      )
  },
  {
    path: "goldreceipt",
    loadChildren: () =>
      import("./modules/gold-receipt/gold-receipt.module").then(
        (m) => m.GoldReceiptModule
      )
  },
  {
    path: 'parent',
    loadChildren: () =>
      import("./modules/parent/parent.module").then(
        (m) => m.ParentModule
      )
  },


];

@NgModule({
  imports: [RouterModule.forRoot(routes),],
  exports: [RouterModule]
})
export class AppRoutingModule { }
